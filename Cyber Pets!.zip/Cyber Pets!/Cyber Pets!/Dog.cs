﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cyber_Pets_
{
    internal class Dog : BasePet
    {
        new public string species = "Dog";
    }
}
