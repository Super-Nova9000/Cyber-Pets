﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cyber_Pets_
{
    internal class Cat : BasePet
    {
        Random rnd = new Random();

        new public string species = "Cat";

        new public void tick()
        {
            timer++;
            if (hunger < 100 && timer % 2 == 0) //If hunger is less than 100, add 1 per tick
            {
                hunger++;
            }

            if (health > 0) //Make sure there is health before continuing to take it
            {
                health = health - Convert.ToInt32(5 * (Math.Pow(hunger * 0.01, 2))); //Remove health using "y=5x^2", where x is (hunger * 0.01) and y is damage
            }
            if (illness > 75 && health > 0) //If pet is extremely ill, take damage
            {
                health--;
            }

            if (rnd.Next(0, 100) == 1 && illness == 0) //1 in 100 chance that pet will fall ill
            {
                illness = 50;
            }
            else if (illness > 0) //If pet is ill, increase illness by 2 per tick
            {
                illness++;
                illness++;
            }
        }
    }
}
