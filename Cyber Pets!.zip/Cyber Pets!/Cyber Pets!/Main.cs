﻿// See https://aka.ms/new-console-template for more information
using Cyber_Pets_;
using System.Data.Common;

Random rnd = new Random();
BasePet pet = new BasePet();

void tickFunction() //Code for tickcycle
{
    while (true)
    {
        pet.tick(); //Do tick
        Thread.Sleep(1000); //Delay before next tick
    }

}

void gameStart()
{
    bool petFail = false;
    bool petValid = false;
    while (petValid == false)
    {
        Console.Clear();
        Console.WriteLine("What species will your pet be?");
        Console.WriteLine("Dog\nCat\nBaby (WIP)");

        if (petFail == true)
        {
            Console.WriteLine("Please enter a valid species");
        }

        string speciesSelect = Console.ReadLine()!;
        if (speciesSelect.ToUpper() == "DOG") //If selected species is dog
        {
            Dog newPet = new Dog();
            pet = newPet; //overwrite BasePet
            petValid = true;
        }
        else if (speciesSelect.ToUpper() == "CAT") //If selected species is cat
        {
            Cat newPet = new Cat();
            pet = newPet; //overwrite BasePet
            petValid = true;
        }
        else if (speciesSelect.ToUpper() == "BABY") //If selected species is baby
        {
            Baby newPet = new Baby();
            pet = newPet; //overwrite BasePet
            petValid = true;
        }
        else
        {
            petFail = true;
        }
    }

    bool nameFail = false;
    bool nameValid = false;
    while (nameValid == false)
    {
        Console.Clear();
        Console.WriteLine("What will your pet be called?");

        if (nameFail == true)
        {
            Console.WriteLine("Please enter a actual name");

        }

        string nameMe = Console.ReadLine()!;
        if (nameMe == "")
        {
            nameFail = true;
        }
        else
        {
            nameValid = true;
            nameFail = false;
            pet.name = nameMe;
        }
    }
}

char userAct = ' ';
void mainGame() //Main game loop
{
    while (pet.health > 0)
    {
        Console.Clear();
        displayStats();

        string userIn = Console.ReadLine()!;

        if (userIn != "") { userAct = userIn[0]; }
        else { userAct = ' '; }

        if (userAct.ToString().ToUpper() == "F") //If user enters F, feed pet
        {
            pet.feed();
        }
        else if (userAct.ToString().ToUpper() == "B") //If user enters B, use bandage on pet
        {
            pet.bandgage();
        }
        else if (userAct.ToString().ToUpper() == "M") //If user enters M, give pet medicine 
        {
            pet.meds();
        }
        else if (userAct.ToString().ToUpper() == "I")
        {
            Console.WriteLine("unavailable");
        }
    }

}

void displayStats()
{
    Console.WriteLine(pet.name + "'s stats: \n");

    Console.WriteLine("Pet Health: " + pet.health);
    Console.WriteLine("Pet Hunger: " + pet.hunger);
    if (pet.illness > 75) //If pet is v. ill
    {
        Console.WriteLine("Pet is extremely sick!");
    }
    else if (pet.illness > 0) //if pet is ill
    {
        Console.WriteLine("Pet is sick");
    }
    else
    {
        Console.WriteLine("Pet is healthy!");
    }

    if (pet.illness == 100 || pet.health <= 0 || pet.hunger == 100) //If pet is too ill, is dead or has starved
    {
        pet.health = 0; //Make sure health is zero
        Console.Clear(); //Re-print stats
        Console.WriteLine("Pet Health: " + pet.health);
        Console.WriteLine("Pet Hunger: " + pet.hunger);
        if (pet.illness > 75) //If pet is v. ill
        {
            Console.WriteLine("Pet is extremely sick!");
        }
        else if (pet.illness > 0) //if pet is ill
        {
            Console.WriteLine("Pet is sick");
        }
        Console.WriteLine("Pet is dead.\nYour pet survived for " + pet.timer + " seconds."); //Dead pet
    }
}



gameStart();

Thread tickThread = new Thread(new ThreadStart(tickFunction)); 
tickThread.Start();
//Do "tickFunction" on seperate thread

mainGame();

