﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cyber_Pets_
{
    internal class Baby : BasePet
    {
        Random rnd = new Random();

        new public string species = "Baby";
        public int boredom = 0;

        public bool intervention = false;

        new public void tick()
        {
            timer++;
            if (hunger < 100) //If hunger is less than 100, add 1 per tick
            {
                hunger++;
            }

            if (health > 0) //Make sure there is health before continuing to take it
            {
                health = health - Convert.ToInt32(5 * (Math.Pow(hunger * 0.01, 2))); //Remove health using "y=5x^2", where x is (hunger * 0.01) and y is damage
            }
            if (illness > 75 && health > 0) //If pet is extremely ill, take damage
            {
                health--;
            }
            if (boredom < 100)
            {
                boredom += 5;
            }

            if (rnd.Next(0, 100) == 1 && illness == 0) //1 in 100 chance that pet will fall ill
            {
                illness = 50;
            }
            else if (illness > 0) //If pet is ill, increase illness by 2 per tick
            {
                illness++;
                illness++;
            }

            //Baby-specfic random events
            if (boredom >= 90) //if boredom is 90
            {
                if (rnd.Next(1, 5) == 1) //one in 5 chance of event
                {
                    randEvent();
                }
            }
            else if (boredom >= 80) //if boredom is 80
            {
                if (rnd.Next(1, 10) == 1) //one in 10 chance of event
                {
                    randEvent();
                }
            }
            else if (boredom >= 70) //if boredom is 70
            {
                if (rnd.Next(1, 20) == 1) //one in 20 chance of event
                {
                    randEvent();
                }
            }
            else if (boredom >= 60) //if boredom is 60
            {
                if (rnd.Next(1, 50) == 1) //one in 50 chance of event
                {
                    randEvent();
                }
            }
            else if (boredom >= 50) //if boredom is 50
            {
                if (rnd.Next(1, 100) == 1) //one in 100 chance of event
                {
                    randEvent();
                }
            }
        }

        void randEvent()
        {
            boredom = 0;

        }
    }
}
